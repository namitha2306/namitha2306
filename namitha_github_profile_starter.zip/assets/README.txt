Add your actual project demo GIFs here using these filenames:
- call-analytics.gif
- multimodal-abuse-detection.gif
- skin-cancer-detection.gif
Then commit them with README.md. Until you add these files, those three image slots will show as broken images.
